﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Uipath.UrlShortner.Properties.Resources
    {
    }
}