﻿namespace UiPath.Shared.Localization
{
    class SharedResources : UrlShortner.Activities.Properties.Resources
    {
    }
}