using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using UrlShortner.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;

namespace UrlShortner.Activities.Activity
{
    [LocalizedDisplayName(nameof(Resources.URLShortner_DisplayName))]
    [LocalizedDescription(nameof(Resources.URLShortner_Description))]
    public class URLShortner : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedDisplayName(nameof(Resources.URLShortner_URL_DisplayName))]
        [LocalizedDescription(nameof(Resources.URLShortner_URL_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> URL { get; set; }

        [LocalizedDisplayName(nameof(Resources.URLShortner_ShortURL_DisplayName))]
        [LocalizedDescription(nameof(Resources.URLShortner_ShortURL_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> ShortURL { get; set; }

        #endregion


        #region Constructors

        public URLShortner()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (URL == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(URL)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var LongUrl = URL.Get(context);

            string makeTinyURLs;
            makeTinyURLs = "http://tinyurl.com/api-create.php?url=" +
               LongUrl.ToLower();

            System.Net.HttpWebRequest webRequest;
            System.Net.HttpWebResponse webResponse;

            System.IO.StreamReader srReader;

            string strHTML;

            webRequest = (System.Net.HttpWebRequest)System.Net
               .WebRequest.Create(makeTinyURLs);
            webRequest.Method = "GET";

            webResponse = (System.Net.HttpWebResponse)webRequest
               .GetResponse();
            srReader = new System.IO.StreamReader(webResponse
               .GetResponseStream());

            strHTML = srReader.ReadToEnd();

            srReader.Close();
            webResponse.Close();
            webRequest.Abort();

            // Outputs
            return (ctx) => {
                ShortURL.Set(ctx, strHTML);
            };
        }

        #endregion
    }
}

