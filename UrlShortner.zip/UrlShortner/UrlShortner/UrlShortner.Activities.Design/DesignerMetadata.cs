using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using Uipath.UrlShortner.Activities.Design.Designers;
using Uipath.UrlShortner.Activities.Design.Properties;

namespace Uipath.UrlShortner.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(URLShortner), categoryAttribute);
            builder.AddCustomAttributes(typeof(URLShortner), new DesignerAttribute(typeof(URLShortnerDesigner)));
            builder.AddCustomAttributes(typeof(URLShortner), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
