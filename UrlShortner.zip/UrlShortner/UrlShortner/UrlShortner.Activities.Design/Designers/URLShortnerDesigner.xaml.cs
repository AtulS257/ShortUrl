namespace UrlShortner.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for URLShortnerDesigner.xaml
    /// </summary>
    public partial class URLShortnerDesigner
    {
        public URLShortnerDesigner()
        {
            InitializeComponent();
        }
    }
}
